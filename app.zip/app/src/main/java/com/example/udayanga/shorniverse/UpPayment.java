package com.example.udayanga.shorniverse;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class UpPayment extends AppCompatActivity {

    Button update,delete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_payment);

        update = findViewById(R.id.UpPaym);
        delete = findViewById(R.id.delPym);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast u = Toast.makeText(UpPayment.this, "Updated successfully", Toast.LENGTH_SHORT);
                u.show();
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast d = Toast.makeText(UpPayment.this, "Deleted successfully", Toast.LENGTH_SHORT);
                d.show();
            }
        });
    }
}
