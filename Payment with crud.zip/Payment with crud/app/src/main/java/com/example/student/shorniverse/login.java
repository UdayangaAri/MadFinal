package com.example.student.shorniverse;

import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {

    Button login;
    TextView t1;
    EditText em, pw;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = findViewById(R.id.LogIn);
        t1 = findViewById(R.id.Forgotpw);
        em = findViewById(R.id.Email);
        pw = findViewById(R.id.Pwd);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(login.this,Home1.class);
                startActivity(a);

            }
        });

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent m = new Intent(login.this,ForgotPW.class);
                startActivity(m);
            }
        });


        firebaseAuth = FirebaseAuth.getInstance();

        login = findViewById(R.id.LogIn);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //loadingProgressBar.setVisibility(View.VISIBLE);
                //  loginViewModel.login(usernameEditText.getText().toString(),passwordEditText.getText().toString());

                if (TextUtils.isEmpty(em.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Please enter Email", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(pw.getText().toString())){
                    Toast.makeText(getApplicationContext(), "Please enter Email", Toast.LENGTH_SHORT).show();

                }  else {


                    firebaseAuth.signInWithEmailAndPassword(em.getText().toString(),
                            pw.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {
                                startActivity(new Intent(login.this, Home1.class));
                                String welcomeMsg = "Welcome to Wings";
                                Toast.makeText(getApplicationContext(), welcomeMsg, Toast.LENGTH_LONG).show();
                                finish();

                            } else {
                                Toast.makeText(getApplicationContext(), task.getException().getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });


    }
}
