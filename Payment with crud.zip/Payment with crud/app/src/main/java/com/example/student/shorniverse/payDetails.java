package com.example.student.shorniverse;

public class payDetails {
    private Integer cardNo;
    private Integer cvv;
    private String fName;
    private Integer exDate;
    private String lName;

    public Integer getCardNo() {
        return cardNo;
    }

    public void setCardNo(Integer cardNo) {
        this.cardNo = cardNo;
    }

    public Integer getCvv() {
        return cvv;
    }

    public void setCvv(Integer cvv) {
        this.cvv = cvv;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public Integer getExDate() {
        return exDate;
    }

    public void setExDate(Integer exDate) {
        this.exDate = exDate;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public payDetails() {
    }
}
